package com.my.newproject11;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.Button;
import android.widget.TextView;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import java.util.Timer;
import java.util.TimerTask;
import android.content.SharedPreferences;
import android.view.View;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private double round = 0;
	private double get = 0;
	private double count = 0;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private ImageView imageview1;
	private LinearLayout linear3;
	private Button button1;
	private TextView textview1;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private TextView textview2;
	private TextView textview3;
	private TextView textview4;
	private TextView textview5;
	
	private ObjectAnimator a = new ObjectAnimator();
	private TimerTask timer;
	private SharedPreferences s;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		button1 = (Button) findViewById(R.id.button1);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		s = getSharedPreferences("s", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Note_(" တစ်ခါ rotate လုပ်ပြီး Rotation number ကို နောက်တစ်ခါအတွက် Zero သတ်မှတ်ပေးရပါတယ်။ ");
				imageview1.setRotation((float)(0));
				_Note_("round number variable က လည်ပတ်မဲ့ အပတ်ရေအတွက် 360 နဲ့မြှောက်ဖို့ပါ။");
				_Note_("get Number Variable ကကြတော့ 360 နဲ့ မြှောက်ပြီးသား အပတ်စဥ်တွေအတွက် spin ထဲမှာ သက်ဆိုင်ရာ data တွေရဲ့ degree ကို randan အနေနဲ့ ယူပြီး ထပ်ပေါင်းတာပဲ ဖြစ်ပါတယ်။");
				_Note_("\"a\" anaimation Component ကတော့ Spin photo ကို အထက်ပါ variable နှစ်ခုကရလာတဲ့ တန်ဖိုးအတိုင်း rotation လုပ်ပေးဖို့ဖြစ်ပါတယ်။ ...");
				count++;
				s.edit().putString("count", String.valueOf((long)(count))).commit();
				SketchwareUtil.showMessage(getApplicationContext(), s.getString("count", ""));
				if (count < 10) {
					get = SketchwareUtil.getRandom((int)(1), (int)(7));
					SketchwareUtil.showMessage(getApplicationContext(), "မကျော်သေးပါ။");
				}
				else {
					get = SketchwareUtil.getRandom((int)(1), (int)(8));
					SketchwareUtil.showMessage(getApplicationContext(), "ကျော်ပါပြီ။");
				}
				round = SketchwareUtil.getRandom((int)(2), (int)(3));
				a.setTarget(imageview1);
				a.setPropertyName("rotation");
				a.setFloatValues((float)(0), (float)((round * 360) + ((get * 45) + 22.5d)));
				a.setDuration((int)(2000));
				a.start();
				_Note_("အောက်က Timer ကကြတော့ Animation ပြီးတဲ့ အချိန်မှာ ရလာတဲ့ get rotation သတ်မှတ်ချက်နဲ့ spin က data ကို စစ်ထုတ်ဖို့ဖြစ်ပါတယ်။");
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								if (get == 1) {
									SketchwareUtil.showMessage(getApplicationContext(), "get 200ks");
								}
								if (get == 2) {
									SketchwareUtil.showMessage(getApplicationContext(), "get 100 points");
								}
								if (get == 3) {
									SketchwareUtil.showMessage(getApplicationContext(), "get 50 points");
								}
								if (get == 4) {
									SketchwareUtil.showMessage(getApplicationContext(), "get 50ks");
								}
								if (get == 5) {
									SketchwareUtil.showMessage(getApplicationContext(), "get 200 points");
								}
								if (get == 6) {
									SketchwareUtil.showMessage(getApplicationContext(), "get 500ks");
								}
								if (get == 7) {
									SketchwareUtil.showMessage(getApplicationContext(), "get 100ks");
								}
								if (get == 8) {
									SketchwareUtil.showMessage(getApplicationContext(), "get 1000ks");
								}
							}
						});
					}
				};
				_timer.schedule(timer, (int)(3000));
				_Note_("ယင်း Project ကို Developer Win Htike မှ ကိုယ်တိုင်ဖန်တီးထားခြင်းဖြစ်  ပါသည်။....\n\n\nဖုန်း-09950141131");
				_Note_("FB_link:");
				_Note_("https://www.facebook.com/u.w.htike.1460");
			}
		});
	}
	private void initializeLogic() {
		if (!s.getString("count", "").equals("")) {
			count = Double.parseDouble(s.getString("count", ""));
		}
		SketchwareUtil.showMessage(getApplicationContext(), String.valueOf((long)(count)));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _Note_ (final String _hi) {
		
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
