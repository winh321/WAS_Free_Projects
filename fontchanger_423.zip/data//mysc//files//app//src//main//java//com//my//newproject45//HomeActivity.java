package com.my.newproject45;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.graphics.Typeface;

public class HomeActivity extends Activity {
	
	
	private LinearLayout linear1;
	private LinearLayout linear4;
	private ScrollView vscroll1;
	private TextView textview2;
	private Button button1;
	
	private SharedPreferences s;
	private Intent i = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		textview2 = (TextView) findViewById(R.id.textview2);
		button1 = (Button) findViewById(R.id.button1);
		s = getSharedPreferences("s", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), MainActivity.class);
				startActivity(i);
				s.edit().putString("f", "").commit();
			}
		});
	}
	private void initializeLogic() {
		textview2.setText("မန္တလေးတွင် စစ်ကောင်စီစစ်ကြောင်းမှူးနှင့် စစ်သားတချို့ သေဆုံး\n-------------------------------------------------------\nယနေ့ (ဇွန် ၂၂) နံနက်ပိုင်း မန္တလေးမြို့ပစ်ခတ်မှုများအတွင်း ပြည်သူ့ကာကွယ်ရေးတပ်ဖွဲ့ (PDF) မှ တပ်ဖွဲ့ဝင်တချို့ သေဆုံးခဲ့သည့်နည်းတူ စစ်ကောင်စီဘက်မှလည်း စစ်ကြောင်းမှူးတာဝန်ယူသည့် အရာရှိအပါအဝင် စစ်သားတချို့သေဆုံးကြောင်း မြို့ခံများက ဆိုသည်။  \n\nချမ်းမြသာစည်မြို့နယ်ရှိ PDF တပ်ဖွဲ့ဝင်တို့ ရှိသည့်နေရာကို နံနက် ၈ နာရီခန့်တွင် စစ်ကောင်စီတပ်က အင်အားအလုံးအရင်းဖြင့် ဝိုင်းဝန်းပိတ်ဆို့ ဝင်ရောက်စီးနင်းခဲ့ခြင်းဖြစ်သည်။\n\n“စစ်ကြောင်းမှူးကျတယ်ပြောတယ်။ ဖြစ်တဲ့နေရာနဲ့ နှစ်ပြလောက်အကွာမှာ တပ်စွဲထားတဲ့အဖွဲ့ကလို့ ပြောတယ်” ဟု စစ်ကောင်စီလက်နက်ကိုင်များနှင့် နီးစပ်သည့် မန္တလေးမြို့ခံတစ်ဦးက Myanmar Now ကို ပြောသည်။ \n\nအခြားမန္တလေးမြို့ခံ အမျိုးသမီးတစ်ဦးကလည်း ယနေ့ပစ်ခတ်မှုများအတွင်း စစ်ကောင်စီဘက်မှ စစ်ကြောင်းမှူးအရာရှိအပါအဝင် စစ်သား ၄ ဦး သေဆုံးခဲ့ကြောင်း သိရကြောင်း ပြောသည်။\n\nမန္တလေးမြို့ပေါ်တိုက်ပွဲတွင် PDF လက်ချက်ဖြင့် သေဆုံးသွားသည့် စစ်ကောင်စီအရာရှိမှာ ဗိုလ်မှူးကြီးအောင်မျိုးကျော်ဖြစ်ပြီး ၎င်းသည် စစ်တက္ကသိုလ်အပတ်စဉ် ၄၁ မှ ဖြစ်သည်ဟု အဆိုပါ အရာရှိနှင့် သိကျွမ်းသည့် မြို့ခံတစ်ဦးက Myanmar Now ကို ယနေ့ညပိုင်းတွင် အတည်ပြုသည်။ \n\nစစ်ကောင်စီက နာရီပိုင်းအတွင်း သတင်းထုတ်ပြန်ခဲ့ရာ၌ အပြန်အလှန်ပစ်ခတ်မှုအတွင်း တပ်ဖွဲ့ဝင်အချို့ အပြင်းအထန်ဒဏ်ရာရရှိခဲ့သည်ဟု ဆိုသော်လည်း အတိအကျဖော်ပြထားခြင်း မရှိပေ။ \n\nမန္တလေးမြို့ ၅၄ လမ်းနှင့် ၁၁၁ လမ်းထောင့်ရှိ နေအိမ်တစ်ခုကို သွားရောက်ရှာဖွေစစ်ဆေးစဉ် အပြန်အလှန်ပစ်ခတ်မှုဖြစ်ပွားပြီး PDF တပ်ဖွဲ့ဝင် ၄ ဦးသေဆုံးကာ ၈ ဦးဖမ်းဆီးရမိခဲ့ကြောင်း၊ ၅၃ လမ်း၌ လက်နက်ငယ်များဖြင့် ပစ်ခတ်သည့် မော်တော်ယာဉ်တစ်စီးကို ပိတ်ဆို့ဖမ်းဆီးရာ အဆိုပါယာဉ်မှာ ၅၆ လမ်းနှင့် ၁၁၀ လမ်းထောင့်ရှိ ထရန်စဖော်မာကို ဝင်တိုက်ပြီးနောက် ယာဉ်ပေါ်ပါ ၄ ဦးသေဆုံးခဲ့ကြောင်း စစ်ကောင်စီက ထုတ်ပြန်ခဲ့သည်။ \n\nမန္တလေး PDF အဖွဲ့ကလည်း ၎င်းတို့တပ်ဖွဲ့ဝင်တချို့ရှိသည့်နေရာ စီးနင်းခံရစဉ်အတွင်း အခြားနေရာများမှ မိတ်ဖက်တပ်ဖွဲ့များလည်း ဝင်ရောက်တိုက်ခိုက်ခဲ့ပြီး ထိခိုက်ကျဆုံးမှုအခြေအနေကိုမူ အတည်မပြုနိုင်သေးကြောင်း သတင်းထုတ်ပြန်ခဲ့သည်။ \n\nမန္တလေး PDF ပြန်ကြားရေးတာဝန်ခံ ဗိုလ်ထွန်းတောက်နိုင်ကမူ “ကျွန်တော်တို့ဘက်က ကျဆုံးတာ ၂ ယောက်ရှိတယ်။ အဖမ်းခံရတာက ၆ ယောက်ပါ။ DRPA (အာဏာရှင်တော်လှန်ရေးပြည်သူ့တပ်မတော်) က ၃ ယောက်ကျပါတယ်” ဟု Myanmar Now ကို ပြောသည်။\n\nချမ်းမြသာစည်မြို့နယ်တွင် ယမန်နေ့ညပိုင်းက ဖြစ်ပွားခဲ့သည့် ပေါက်ကွဲမှုတစ်ခုနှင့် ပတ်သက်၍ စစ်ကောင်စီက လိုက်လံစစ်ဆေးရာမှတစ်ဆင့် PDF တပ်ဖွဲ့ဝင်တချို့ရှိရာနေရာကို ဝင်ရောက်စီးနင်းခံရခြင်းဖြစ်ကြောင်းလည်း ၎င်းက ပြောသည်။ \n\n“လေးမျက်နှာဘက်မှာ ပေါက်ကွဲမှုတစ်ခုဖြစ်တယ်။ သူတို့ရဲ့ အကြီးအကဲထဲက တစ်ယောက်သေသွားတယ်။ သူတို့ဘက်က အထိနာသွားတော့ ပတ်ဝန်းကျင်ကို စစ်တယ်။ တစ်အိမ်ဝင်တစ်အိမ်ထွက် စစ်တဲ့အခါမှာ ကျွန်တော်တို့လူက အစစ်မခံဘူး။ အစစ်ခံလို့လည်းမရဘူး။ လေးမျက်နှာနဲ့ ကျွန်တော်တို့ရုံးနဲ့က မဝေးဘူး။ အစစ်မခံတာကနေ အချေအတင်ဖြစ်ကြတာ” ဟု ၎င်းက ပြောသည်။\n\nစစ်ကားနှင့် ရဲကား အစီးရေ ၂၀ ခန့်ပါဝင်သည့် အင်အားအလုံးအရင်းဖြင့် ဝိုင်းဝန်းပိတ်ဆို့ကာ ဝင်ရောက်စီးနင်းစဉ် PDF တပ်ဖွဲ့ဝင်များက ပြန်လည်ပစ်ခတ်သည့်နည်းတူ စစ်ကောင်စီတပ်ဖွဲ့ကလည်း လက်နက်ကြီးဖြင့်ပါ ပစ်ခတ်သည်ကို ရုပ်သံမှတ်တမ်းများတွင် တွေ့ရသည်။\n\nထိုသို့ ဝင်ရောက်စီးနင်းခံရပြီးနောက် အင်အားချင်းမမျှသောကြောင့် ထိုနေရာကို လက်လွှတ်ခဲ့ရကြောင်း ဗိုလ်ထွန်းတောက်နိုင်က ပြောသည်။\n\n“ဖြစ်သွားတာက တအားကို မြန်တယ်။ ရှောင်လို့မရတဲ့ အနေအထားဖြစ်သွားတာ။ ပိတ်မိသွားတယ်။ သတင်းက သူတို့ရောက်ပြီးမှ သတင်းရတာ။ ကျွန်တော်တို့ နောက်ကျသွားတယ်လို့ ပြောလို့ရတယ်။ သူတို့ ဝိုင်းထားတဲ့အချိန်မှာ ကျွန်တော်တို့က အပြင်ကနေ ပြန်ဝိုက်ထားပြီးသား။ အထဲကလူတွေကို ပြန်ကယ်ထုတ်လို့မရတဲ့ အနေအထားမို့သာ။ ကျွန်တော်တို့ဝင်လိုက်ရင် အသက်ရှင်မှာမဟုတ်တော့လို့ လွှတ်ပေးလိုက်ရတဲ့ အနေအထားပါ” ဟု ၎င်းက ဆိုသည်။\n\nအပြန်အလှန်ပစ်ခတ်မှုဖြစ်ပွားရာနေရာအနီး ရှိနေစဉ် ဦးခေါင်းထိ အမျိုးသမီးငယ်၊ ကျောထိ အမျိုးသားတစ်ဦးတို့ကို ကုသမှုပေးခဲ့ရကြောင်း လူမှုကယ်ဆယ်ရေးအသင်းတစ်ခုထံမှ သိရသည်။ \n\nပစ်ခတ်မှုများအပြီး မြို့ပေါ်ရှိ နေရာတချို့တွင် ပေါက်ကွဲမှုများဖြစ်ပွားခဲ့ကြောင်း၊ စစ်ကောင်စီတပ်များကို ဟန့်တားရန် လမ်းပေါ်၌ ကားတာယာများမီးရှို့ကြကြောင်း မြို့ခံများက ဆိုသည်။ \n\nညနေ ၃ နာရီခွဲ အချိန်ခန့်က ၆၆ လမ်းရှိ မန္တလေးတိုင်းရဲတပ်ဖွဲ့ရုံးရှေ့မှ ရဲများကို ဆိုင်ကယ်သမားက သွားရောက်ပစ်ခတ်သဖြင့် ရဲတစ်ဦးသေဆုံးကြောင်း မျက်မြင်တွေ့ရှိသူတစ်ဦးကို ကိုးကားလျက် မဇ္စျိမသတင်းဌာနက ရေးသားထားသည်။\n\nစစ်ကောင်စီက ပိတ်ဆို့ရှာဖွေခဲ့သည့်အပြင် ယနေ့ညနေပိုင်းတွင် မြို့အဝင်အထွက်နေရာများ၊ မြို့တွင်းနေအိမ်များတွင် ရှာဖွေစစ်ဆေးကြောင်း၊ သေနတ်သံများလည်း ကြားရကြောင်း မြို့ခံများက Myanmar Now ကို ပြောသည်။");
		if ("zaw".equals(s.getString("f", ""))) {
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/zawgyi.ttf"), 0);
		}
		else {
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/pyidaungsu.ttf"), 0);
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
