package com.my.TICTACTOE.KATA;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ImageView;
import java.util.Timer;
import java.util.TimerTask;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private String current_mark = "";
	private String player2 = "";
	private double n = 0;
	private String player1 = "";
	
	private LinearLayout linear2;
	private LinearLayout board;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private TextView textview1;
	private Button button1;
	private Button button2;
	private Button button3;
	private Button button4;
	private Button button5;
	private Button button6;
	private Button button7;
	private Button button8;
	private Button button9;
	private TextView textview2;
	private LinearLayout linear9;
	private LinearLayout start;
	private ImageView imageview1;
	private TextView textview3;
	
	private TimerTask tim;
	private AlertDialog.Builder dia;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		board = (LinearLayout) findViewById(R.id.board);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		textview1 = (TextView) findViewById(R.id.textview1);
		button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		button3 = (Button) findViewById(R.id.button3);
		button4 = (Button) findViewById(R.id.button4);
		button5 = (Button) findViewById(R.id.button5);
		button6 = (Button) findViewById(R.id.button6);
		button7 = (Button) findViewById(R.id.button7);
		button8 = (Button) findViewById(R.id.button8);
		button9 = (Button) findViewById(R.id.button9);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		start = (LinearLayout) findViewById(R.id.start);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview3 = (TextView) findViewById(R.id.textview3);
		dia = new AlertDialog.Builder(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_click(button1);
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_click(button2);
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_click(button3);
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_click(button4);
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_click(button5);
			}
		});
		
		button6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_click(button6);
			}
		});
		
		button7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_click(button7);
			}
		});
		
		button8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_click(button8);
			}
		});
		
		button9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_click(button9);
			}
		});
		
		start.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_restart();
			}
		});
	}
	private void initializeLogic() {
		board.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _click (final TextView _view) {
		_view.setText(current_mark);
		if (button1.getText().toString().equals(player1) && (button2.getText().toString().equals(player1) && button3.getText().toString().equals(player1))) {
			SketchwareUtil.showMessage(getApplicationContext(), "player 1 wins");
			start.setVisibility(View.VISIBLE);
			board.setVisibility(View.GONE);
		}
		else {
			if (button1.getText().toString().equals(player2) && (button2.getText().toString().equals(player2) && button3.getText().toString().equals(player2))) {
				SketchwareUtil.showMessage(getApplicationContext(), "player 2 wins");
				start.setVisibility(View.VISIBLE);
				board.setVisibility(View.GONE);
			}
			else {
				if (button4.getText().toString().equals(player1) && (button5.getText().toString().equals(player1) && button6.getText().toString().equals(player1))) {
					SketchwareUtil.showMessage(getApplicationContext(), "player 1 wins");
					start.setVisibility(View.VISIBLE);
					board.setVisibility(View.GONE);
				}
				else {
					if (button4.getText().toString().equals(player2) && (button5.getText().toString().equals(player2) && button6.getText().toString().equals(player2))) {
						SketchwareUtil.showMessage(getApplicationContext(), "player 2 wins");
					}
					else {
						if (button7.getText().toString().equals(player1) && (button8.getText().toString().equals(player1) && button9.getText().toString().equals(player1))) {
							SketchwareUtil.showMessage(getApplicationContext(), "player 1 wins");
							start.setVisibility(View.VISIBLE);
							board.setVisibility(View.GONE);
						}
						else {
							if (button7.getText().toString().equals(player2) && (button8.getText().toString().equals(player2) && button9.getText().toString().equals(player2))) {
								SketchwareUtil.showMessage(getApplicationContext(), "player 2 wins");
								start.setVisibility(View.VISIBLE);
								board.setVisibility(View.GONE);
							}
							else {
								if (button1.getText().toString().equals(player1) && (button4.getText().toString().equals(player1) && button7.getText().toString().equals(player1))) {
									SketchwareUtil.showMessage(getApplicationContext(), "player 1 wins");
									start.setVisibility(View.VISIBLE);
									board.setVisibility(View.GONE);
								}
								else {
									if (button1.getText().toString().equals(player2) && (button4.getText().toString().equals(player2) && button7.getText().toString().equals(player2))) {
										SketchwareUtil.showMessage(getApplicationContext(), "player 2 wins");
										start.setVisibility(View.VISIBLE);
										board.setVisibility(View.GONE);
									}
									else {
										if (button2.getText().toString().equals(player1) && (button5.getText().toString().equals(player1) && button8.getText().toString().equals(player1))) {
											SketchwareUtil.showMessage(getApplicationContext(), "player 1 wins");
											start.setVisibility(View.VISIBLE);
											board.setVisibility(View.GONE);
										}
										else {
											if (button2.getText().toString().equals(player2) && (button5.getText().toString().equals(player2) && button8.getText().toString().equals(player2))) {
												SketchwareUtil.showMessage(getApplicationContext(), "player 2 wins");
												start.setVisibility(View.VISIBLE);
												board.setVisibility(View.GONE);
											}
											else {
												if (button3.getText().toString().equals(player1) && (button6.getText().toString().equals(player1) && button9.getText().toString().equals(player1))) {
													SketchwareUtil.showMessage(getApplicationContext(), "player 1 wins");
													start.setVisibility(View.VISIBLE);
													board.setVisibility(View.GONE);
												}
												else {
													if (button3.getText().toString().equals(player2) && (button6.getText().toString().equals(player2) && button9.getText().toString().equals(player2))) {
														SketchwareUtil.showMessage(getApplicationContext(), "player 2 wins");
														start.setVisibility(View.VISIBLE);
														board.setVisibility(View.GONE);
													}
													else {
														if (button1.getText().toString().equals(player1) && (button5.getText().toString().equals(player1) && button9.getText().toString().equals(player1))) {
															SketchwareUtil.showMessage(getApplicationContext(), "player 1 wins");
															start.setVisibility(View.VISIBLE);
															board.setVisibility(View.GONE);
														}
														else {
															if (button1.getText().toString().equals(player2) && (button5.getText().toString().equals(player2) && button9.getText().toString().equals(player2))) {
																SketchwareUtil.showMessage(getApplicationContext(), "player 2 wins");
																start.setVisibility(View.VISIBLE);
																board.setVisibility(View.GONE);
															}
															else {
																if (button3.getText().toString().equals(player1) && (button5.getText().toString().equals(player1) && button7.getText().toString().equals(player1))) {
																	SketchwareUtil.showMessage(getApplicationContext(), "player 1 wins");
																	start.setVisibility(View.VISIBLE);
																	board.setVisibility(View.GONE);
																}
																else {
																	if (button3.getText().toString().equals(player2) && (button5.getText().toString().equals(player2) && button7.getText().toString().equals(player2))) {
																		SketchwareUtil.showMessage(getApplicationContext(), "player 2 wins");
																		start.setVisibility(View.VISIBLE);
																		board.setVisibility(View.GONE);
																	}
																	else {
																		if (!button1.getText().toString().equals("") && (!button2.getText().toString().equals("") && (!button3.getText().toString().equals("") && (!button4.getText().toString().equals("") && (!button5.getText().toString().equals("") && (!button6.getText().toString().equals("") && (!button7.getText().toString().equals("") && (!button8.getText().toString().equals("") && !button9.getText().toString().equals(""))))))))) {
																			SketchwareUtil.showMessage(getApplicationContext(), "Match Draw");
																			start.setVisibility(View.VISIBLE);
																			board.setVisibility(View.GONE);
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		_view.setEnabled(false);
		if (current_mark.equals("X")) {
			current_mark = "O";
		}
		else {
			current_mark = "X";
		}
	}
	
	
	private void _restart () {
		dia.setTitle("player 1 chose your mark");
		dia.setPositiveButton("X", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				current_mark = "X";
				player1 = "X";
				player2 = "O";
				button1.setEnabled(true);
				button1.setText("");
				button2.setEnabled(true);
				button2.setText("");
				button3.setEnabled(true);
				button3.setText("");
				button4.setEnabled(true);
				button4.setText("");
				button5.setEnabled(true);
				button5.setText("");
				button6.setEnabled(true);
				button6.setText("");
				button7.setEnabled(true);
				button7.setText("");
				button8.setEnabled(true);
				button8.setText("");
				button9.setEnabled(true);
				button9.setText("");
				board.setVisibility(View.VISIBLE);
				start.setVisibility(View.GONE);
			}
		});
		dia.setNegativeButton("O", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				current_mark = "O";
				player1 = "O";
				player2 = "X";
				board.setVisibility(View.GONE);
				button1.setEnabled(true);
				button1.setText("");
				button2.setEnabled(true);
				button2.setText("");
				button3.setEnabled(true);
				button3.setText("");
				button4.setEnabled(true);
				button4.setText("");
				button5.setEnabled(true);
				button5.setText("");
				button6.setEnabled(true);
				button6.setText("");
				button7.setEnabled(true);
				button7.setText("");
				button8.setEnabled(true);
				button8.setText("");
				button9.setEnabled(true);
				button9.setText("");
				board.setVisibility(View.VISIBLE);
				start.setVisibility(View.GONE);
			}
		});
		dia.create().show();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
